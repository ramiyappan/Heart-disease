

	*** READ ME ***

1. Download and import all required files	
2. Open the code GD.ipynb in jupyter notebook or GD.py (attached both formats) and run each code segment in the same order.
3. Check the gradient descent loop with different iterations and learning rates as mentioned.
4. Have included comments for print statements inside loops to check values.
5. I stored all files in jupyter notebook hence can directly access it in the program. 
(If downloading it somewhere else, have to change the file path in the program.)
